<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a href="<?php echo e(route('blog.index')); ?>" class="navbar-brand">Laravel Guide</a>
            <ul class="nav navbar-nav">
                <li><a href="<?php echo e(route('blog.index')); ?>">Blog</a></li>
                <li><a href="<?php echo e(route('other.about')); ?>">About</a></li>
            </ul>
        </div>
    </div>
</nav>